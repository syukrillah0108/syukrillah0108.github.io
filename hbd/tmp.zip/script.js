// ============================================
// DAFTAR EMOJI RANDOM (Nuansa Kocak & Bau)
// ============================================
const emojiList = ["😂", "💨", "💩", "🤢", "😷", "🤡", "✨", "🎬", "🎞️"];

// ============================================
// DATA TRANSKRIP (SINKRONISASI AUDIO)
// Diambil dari file SRT dan diubah ke Detik
// ============================================
const bdayData = {
    "config": {
        "senderName": "Faisal",
        "audioId": "bgMusic"
    },
    "slides": [
        {
            "id": 1,
            "waktu_detik": 0.0,
            "photo": "foto1.jpg",
            "title": "Puisi Hitut",
            "deskripsi": "Persiapkan dirimu untuk mahakarya sastra paling wangi abad ini..."
        },
        {
            "id": 2,
            "waktu_detik": 4.2,
            "photo": "foto2.jpg",
            "title": "Jalma Jujur",
            "deskripsi": "Jalma anu daek ngaku lamun ges hitut."
        },
        {
            "id": 3,
            "waktu_detik": 9.0,
            "photo": "foto3.jpg",
            "title": "Jalma Teu Jujur",
            "deskripsi": "Jalma nu hitut tuluy nyalahkeun batur."
        },
        {
            "id": 4,
            "waktu_detik": 17.0,
            "photo": "foto4.jpg",
            "title": "Jalma Belegug",
            "deskripsi": "Jalma anu nahan hitut, mang jam-jam lilana."
        },
        {
            "id": 5,
            "waktu_detik": 24.0,
            "photo": "foto5.jpg", // Boleh pakai foto yang diulang-ulang
            "title": "Jalma nu Berwawasan",
            "deskripsi": "Jalma anu apal, iaraha kuduna hitut."
        },
        {
            "id": 6,
            "waktu_detik": 31.2,
            "photo": "foto6.jpg",
            "title": "Jalma nu Misterius",
            "deskripsi": "Jalma anu hitut, tapi batur eweuh anu nyahoeun."
        },
        {
            "id": 7,
            "waktu_detik": 42.3,
            "photo": "foto7.jpg",
            "title": "Jalma nu sok Gugup",
            "deskripsi": "Jalma nu ujug-ujug nahan hitut mun keur hitut."
        },
        {
            "id": 8,
            "waktu_detik": 48.0,
            "photo": "foto8.jpg",
            "title": "Jalma nu Percaya Diri",
            "deskripsi": "Jalma nu ngayakinan Hitutna seungit."
        },
        {
            "id": 9,
            "waktu_detik": 54.0,
            "photo": "foto9.jpg",
            "title": "Jalma nu Sadis",
            "deskripsi": "Jalma nu hitut bari di bekep kulengeun, tuluy di bekepkeun ka irung batur."
        },
        {
            "id": 10,
            "waktu_detik": 82.0,
            "photo": "foto10.jpg",
            "title": "Jalma nu Isinan",
            "deskripsi": "Jalma nu hitutna teu tisada, tapi ngarasa isin sorangan"
        },
        {
            "id": 11,
            "waktu_detik": 92.9,
            "photo": "foto11.jpg",
            "title": "Jalma Bodoh",
            "deskripsi": "Lamun geus hitut tuluy narik nafas, karena gantian hitut..."
        }
    ]
};

// ============================================
// LOGIKA SISTEM OTOMATIS
// ============================================
let activeIndex = -1; // Menyimpan index slide yang sedang tampil
const audioEl = document.getElementById(bdayData.config.audioId);

document.addEventListener("DOMContentLoaded", () => {
    renderSlides();
    setupAudioSync();
});

// 1. Render Semua Slide (Tapi Disembunyikan Dulu)
function renderSlides() {
    const wrapper = document.getElementById('slideshow');
    bdayData.slides.forEach((slide) => {
        const slideDiv = document.createElement('div');
        // Slide di set opacity 0 dan posisi hidden (display none diatur oleh class hidden)
        slideDiv.className = `slide-card`; 
        slideDiv.id = `slide-${slide.id}`;
        
        slideDiv.innerHTML = `
            <div class="film-photo-wrapper">
                <img src="${slide.photo}" class="slide-img">
            </div>
            <h2 class="slide-title">${slide.title}</h2>
            <p class="slide-text">${slide.deskripsi}</p>
            <div style="margin-top:15px; font-size:0.8rem; color:#666; font-family:monospace;">
                TIMECODE: ${slide.waktu_detik}s | ARCHIVE 00${slide.id}
            </div>
        `;
        wrapper.appendChild(slideDiv);
    });
}

// 2. Fungsi Tombol Mulai
function startAutoCinema() {
    // Mulai Putar Audio
    audioEl.play().catch(e => console.log("Auto-play diblokir browser."));
    
    // Animasi Layar Terbuka
    const welcome = document.getElementById('welcomeScreen');
    welcome.style.transform = 'translateY(-100%)';
    
    setTimeout(() => {
        welcome.classList.add('hidden');
        document.getElementById('app').classList.remove('hidden');
    }, 1500);
}

// 3. Engine Sinkronisasi (Berjalan Terus Menerus Selama Audio Play)
function setupAudioSync() {
    const timeDisplay = document.getElementById('timeIndicator');

    audioEl.addEventListener('timeupdate', () => {
        const currentTime = audioEl.currentTime;
        
        // Format Tampilan Waktu (Opsional untuk di layar)
        const m = Math.floor(currentTime / 60).toString().padStart(2, '0');
        const s = Math.floor(currentTime % 60).toString().padStart(2, '0');
        timeDisplay.innerText = `REC \u25CF ${m}:${s}`;

        // Cek slide mana yang harus tampil berdasarkan waktu
        let newActiveIndex = -1;
        for (let i = 0; i < bdayData.slides.length; i++) {
            if (currentTime >= bdayData.slides[i].waktu_detik) {
                newActiveIndex = i; // Terus timpa sampai waktu terbesar yang masih < currentTime
            }
        }

        // Jika index berubah (waktunya ganti slide)
        if (newActiveIndex !== activeIndex && newActiveIndex !== -1) {
            changeSlideTo(newActiveIndex);
            activeIndex = newActiveIndex;
        }
    });
}

// 4. Fungsi Transisi Slide
function changeSlideTo(index) {
    const slides = document.querySelectorAll('.slide-card');
    
    // Matikan semua slide
    slides.forEach(slide => {
        slide.classList.remove('active-slide');
    });

    // Nyalakan slide yang aktif
    slides[index].classList.add('active-slide');
    
    // Tembakkan Efek Emoji setiap kali slide ganti
    spawnEmojis();
}

// 5. Fungsi Memunculkan Emoji Random
function spawnEmojis() {
    const container = document.getElementById('emoji-container');
    const numEmojis = Math.floor(Math.random() * 8) + 12; // 12 - 20 emoji sekaligus

    for (let i = 0; i < numEmojis; i++) {
        const emojiEl = document.createElement('div');
        const randomEmoji = emojiList[Math.floor(Math.random() * emojiList.length)];
        emojiEl.innerText = randomEmoji;

        const willPop = Math.random() < 0.4;
        emojiEl.className = willPop ? 'emoji-bubble pop-up' : 'emoji-bubble float-up';
        emojiEl.style.left = Math.floor(Math.random() * 90) + 'vw';
        emojiEl.style.fontSize = (Math.random() * 1.5 + 1.5) + 'rem';
        
        const duration = Math.random() * 2 + 1.5; // Agak dicepatin
        emojiEl.style.animationDuration = duration + 's';

        container.appendChild(emojiEl);
        setTimeout(() => emojiEl.remove(), duration * 1000);
    }
}